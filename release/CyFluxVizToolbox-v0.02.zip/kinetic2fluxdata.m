function [fluxdata] = kinetic2fluxdata(modelId, speciesIds, reactionIds, t, c, v)
% kinetic2fluxdata : Convert ODE results to fluxdata

fluxdata.modelId = modelId;

% every single time point handeled as an individual flux/concentration
% distribution
Nt = numel(t);
fluxdata.simIds = cell(Nt, 1);
for k=1:Nt
   fluxdata.simIds{k} = sprintf('%03i_kin_t-%3.1f', k, t(k)); 
end

% generate the time vector
fluxdata.time = t;

% generate the flux matrix
fluxdata.reactionIds = reactionIds;
fluxdata.fluxes = v';

% generate the concentration matrix
fluxdata.speciesIds = speciesIds;
fluxdata.concentrations = c';

c



