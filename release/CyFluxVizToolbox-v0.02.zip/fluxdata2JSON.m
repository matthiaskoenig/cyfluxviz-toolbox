function [] = fluxdata2JSON(fluxdata, json_file)
% fluxdata2JSON : Writes the fluxdata for CyFluxViz to JSON file. 
 
% TODO

end