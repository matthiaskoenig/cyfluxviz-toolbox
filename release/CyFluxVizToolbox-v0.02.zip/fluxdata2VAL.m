function [] = fluxdata2VAL(fluxdata, folder)
% fluxdata2XML : Writes the fluxdata for CyFluxViz to VAL files 
% in the given folder. 
% Names of the *.val files correspond to the solution Ids 
% (solIds of the fluxdata struct).

% TODO

end