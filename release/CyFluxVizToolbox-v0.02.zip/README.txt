###############################################################################
CyFluxVizToolbox
###############################################################################
CyFluxVizToolbox is a collection of Matlab scripts and functions for the 
generation of CyFluxViz files for visualization.
CyFluxVizToolbox supports COBRA output which can be directly converted 
into flux files for CyFluxViz.

	author: Matthias K�nig
	affiliation: Charite Berlin
	contact: matthias.koenig@charite.de
	data: 2013-08-01
	Copyright � Matthias K�nig 2013 All Rights Reserved.

Please cite:
	Matthias K�nig and Hermann-Georg Holzh�tter
	FluxViz - Cytoscape Plug-in for Vizualisation of Flux Distributions in 
	Networks
	Genome Informatics 2010, Vol.24, p.96-103
	http://www.ncbi.nlm.nih.gov/pubmed?term=22081592

###############################################################################
    This file is part of CyFluxVizToolbox.

    CyFluxVizToolbox is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    CyFluxVizToolbox is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CyFluxVizToolbox.  If not, see <http://www.gnu.org/licenses/>.


###############################################################################
	Installation
###############################################################################
From MATLAB, run
  initCyFluxVizToolbox

Usage examples are provided in the
	./examples
subfolder.

For COBRA support the COBRA Toolbox has to be installed (for further information
see http://opencobra.sourceforge.net/openCOBRA/Welcome.html)

For some features (mainly the conversion of C13 flux data to CyFluxViz formats)
SBML support is needed and consequently the SBML Toolbox has to be installed.
For further information see http://sbml.org/Software/SBMLToolbox)


###############################################################################
	ChangeLog 
###############################################################################
v0.03
- first implementation of the the file parsers & examples


