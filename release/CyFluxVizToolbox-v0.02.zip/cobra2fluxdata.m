function [fluxdata] = cobra2fluxdata(modelId, model, solIds, solutions)
% cobra2fluxdata : Convert the COBRA solutions to fluxdata.
%
% modelId : SBML model ID found in the <model> tag of the SBML
% model : COBRA model with which the simulations were performed
% solIds : cell array of unique solution ids 
% solutions : cell array of solution vectors from COBRA(sol.x)

fluxdata.modelId = modelId;
fluxdata.reactionIds = model.rxns;
fluxdata.simIds = solIds;

% generate the flux matrix
Nv = numel(model.rxns);
Ns = numel(solIds);
fluxdata.fluxes = zeros(Nv, Ns);  % [Nv x Ns]
for k=1:Ns
    fluxdata.fluxes(:,k) = solutions{k};          
end
