function [fluxdata, sources, targets] = C13flux(modelId, fluxInFile, sbmlOutFile, xmlOutFile)
% C13flux: Generate the SBML and the CyFluxViz XML files from C13flu
% [1] Load the flux data (s -> t)
% first column : source node s
% second column : target node t
% column 3, ... : flux data
[fluxes, nodes, ~] = xlsread(fluxInFile);

% get the source and target nodes of the network
% ! no '-' or ' ' allowed in names, have to be replaced
% ! names can not start with numbers
% Restrictions of the SBML IDs ! 
sources = nodes(:,1);
targets = nodes(:,2);
sources = generateSBMLIds(sources);
targets = generateSBMLIds(targets);
clear nodes

% all missing fluxes set to zero
fluxes(isnan(fluxes)) = 0.0;

% generate the SBML model from source and target nodes
C13flux2SBML(modelId, sources, targets, sbmlOutFile)

% generate reactionIds from the sources and target names
reactionIds = generateC13ReactionIds(sources, targets);

% generate ids for the various solutions
solIds = cell(size(fluxes,2),1);
for k=1:numel(solIds)
   solIds{k,1} = sprintf('C13_sol_%i', k); 
end

% generate the fluxdata struct
fluxdata = C13flux2fluxdata(modelId, reactionIds, solIds, fluxes)

% generate the CyFluxViz XML file
fluxdata2XML(fluxdata, xmlOutFile)

end
