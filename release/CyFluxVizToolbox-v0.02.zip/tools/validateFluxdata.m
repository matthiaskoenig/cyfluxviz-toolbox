function [] = validateFluxdata(fluxdata, model)
% checkFluxdata Checks if the fluxdata has the right format for
% visualization with CyFluxViz

snames = fluxdata.simNames;
rnames = fluxdata.reactionNames;
Ns = length(snames);
Nr = length(rnames);
fluxes = fluxdata.fluxes;           % [Nv x Ns] 


% Check if all the names are defined in the model

if (nargin == 3)
  
    % test the matrices
    Nv = length(model.reactions);
    Ns = length(names);
    if (length(fluxes ~= 0))
        [tmp1, tmp2] = size(fluxes);
        if (tmp1 ~= Nv)
            error('Data matrix vData has wrong dimension');
        end
        if (tmp2 ~= Ns)
            error('Names not fitting to data matrix.');
        end%{

    Nx = length(model.metabolites);
    if (length(xData ~= 0))
        [tmp3, tmp4] = size(xData);
        if (tmp4 ~= Nx)
        error('Data matrix xData has wrong dimension');
    end
    if (tmp3 ~= length(names))
        error('Names not fitting to data matrix.'); 
    end
end
%}
    end

    
    
end
